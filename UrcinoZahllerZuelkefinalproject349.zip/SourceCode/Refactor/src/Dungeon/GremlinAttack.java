package Dungeon;

public class GremlinAttack implements Attack {
    public String name(){
        return "";
    }

    public void attack(DungeonCharacter attacker, DungeonCharacter opponent){

    }
}
